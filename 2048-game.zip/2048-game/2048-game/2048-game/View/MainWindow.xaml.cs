﻿using _2048_game.ViewModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;
using System.Windows.Documents;

namespace _2048_game
{
    public partial class MainWindow : Window
    {

        List<StatisticItem> statistics = new List<StatisticItem>();

        public MainWindow()
        {
            InitializeComponent();
            BinaryFormatter formatter = new BinaryFormatter();

            if (File.Exists("statisticsUsers.dat"))
            {
                using (FileStream stream = new FileStream("statisticsUsers.dat", FileMode.Open))
                {
                    statistics = (List<StatisticItem>)formatter.Deserialize(stream);

                }
            }
            DataContext = new MainWindowViewModel();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void StatisticsButton_Click(object sender, RoutedEventArgs e)
        {

            StatisticsWindow statisticsWindow = new StatisticsWindow();

            if (StatisticsViewModel._statistics != null)
            {
                statistics.Add(StatisticsViewModel._statistics[0]);

                BinaryFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream("statisticsUsers.dat", FileMode.Create))
                {
                    formatter.Serialize(stream, statistics);
                }
            }
            statisticsWindow.StatisticsListView.ItemsSource = statistics;

            statisticsWindow.Show();
        }

    }
}
