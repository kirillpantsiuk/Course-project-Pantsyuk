﻿using System.Windows;

namespace _2048_game
{
    public partial class StatisticsWindow : Window
    {
        public StatisticsWindow()
        {
            InitializeComponent();
        }
    }
}
