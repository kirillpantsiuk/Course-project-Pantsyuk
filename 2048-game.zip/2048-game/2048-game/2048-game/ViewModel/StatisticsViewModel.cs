﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace _2048_game
{
    public class StatisticsViewModel : INotifyPropertyChanged
    {

        static public ObservableCollection<StatisticItem> _statistics = null;

        public ObservableCollection<StatisticItem> Statistics
        {
            get { return _statistics; }
            set
            {
                if (_statistics != value)
                {
                    _statistics = value;
                    OnPropertyChanged(nameof(Statistics));
                }
            }
        }

        public StatisticsViewModel(StatisticsData statisticsData)
        {
            if (statisticsData.PlayerNickname != string.Empty)
            {
                _statistics = new ObservableCollection<StatisticItem>
                {
                    new StatisticItem { Nickname = statisticsData.PlayerNickname, Score = statisticsData.Score },
                };
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    [Serializable]
    public class StatisticItem
    {
        public string Nickname { get; set; }
        public int Score { get; set; }
    }
}
