﻿using System;

[Serializable] // Цей атрибут дозволяє сериализувати  объект цього класса
public class StatisticsData
{
    public string PlayerNickname { get; set; }
    public int Score { get; set; }
    public int TheBestScore { get; set; }
    
}
